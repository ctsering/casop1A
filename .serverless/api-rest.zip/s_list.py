import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='ctsering',
    application_name='todo-list-serverless',
    app_uid='SmQl4ktr24PXRDQkQ0',
    org_uid='9b7e84e4-9543-4b68-a357-3e696f3ab418',
    deployment_uid='b941051f-c8af-4fbc-989c-1fa64295b561',
    service_name='api-rest',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.1.4',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'api-rest-dev-list', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/list.list')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
